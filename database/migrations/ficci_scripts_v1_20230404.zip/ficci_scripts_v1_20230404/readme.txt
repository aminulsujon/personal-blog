// script for https://ficci.org.bd/

// tips: include the texts of script.txt in your head section of html
// code sample: <head>{{script-text-goes-here}}</head>
// scripts field value should be changed as per administrative policy

// script by: aminul@crenotive.com
// script date: 04 april 2023
// crenotive service: https://crenotive.com/service/
// Crenotive Digital Solution © 2023